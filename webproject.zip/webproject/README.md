# E-Commerce Application Web Technologies-II Project

This is an Ecommerce Application named 'PES Ecommerce', built using AJAX, Bootstrap Framework, 
MySQL Database and a PayPal Sandbox REST API implementation. 
It is a fully functional E-Commerce portal with features like registration, login, categories of products,
searching, add to shopping cart and make payment. It is submitted as part of our 7th Semester Web Technologies-II Project.

Submitted By  : 01FB17ECS708  Chethana M
                01Fb17ECS706  Chadana M
				01FB16ECS156  Karthik manjunath
                01FB16ECS147  Jeevan M			